def be_add(x,y):
    return x+y

def be_print_str(stuff):
    print(stuff)
    return

def be_print_num(number):
    print(number)
    return

def be_print_process(process):
    print(process)
    return
#print(be_add(2,3))
