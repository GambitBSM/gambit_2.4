def py_add(x,y):
    return x+y

def py_print_str(stuff):
    print(stuff)
    return

def py_print_double(number):
    print(number)
    return
